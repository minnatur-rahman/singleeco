@extends('admin.layouts.template')
@section('page_title')
Dashboard - Single Ecom
@endsection
@section('content')
<h1>This is add Dashboard page</h1>
@endsection
