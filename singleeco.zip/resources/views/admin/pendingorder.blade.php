@extends('admin.layouts.template')
@section('page_title')
Pending Order - Single Ecom
@endsection
@section('content')
<h1>This is pending order page</h1>
@endsection
