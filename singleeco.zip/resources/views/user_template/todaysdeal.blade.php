@extends('user_template.layouts.template')
@section('main-content')
<h1>I am New Today Deal page</h1>
@endsection
