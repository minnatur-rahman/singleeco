@extends('user_template.layouts.template')
@section('main-content')
<h1>Single Product page</h1>
@endsection
