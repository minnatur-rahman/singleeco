@extends('user_template.layouts.template')
@section('main-content')
<h1>I am Add To Cart page</h1>
@endsection
