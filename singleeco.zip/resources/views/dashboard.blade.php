@extends('admin.layouts.template')
@section('page_title')
Dashboard - Single Ecom
@section('content')
<h1>This is dashboard page</h1>
@endsection
