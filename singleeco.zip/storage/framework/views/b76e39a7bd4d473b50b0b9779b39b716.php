<?php $__env->startSection('main-content'); ?>
<div class="fashion_section">
    <div id="main_slider">
        <div class="container">
            <h1 class="fashion_taital"><?php echo e($category->category_name); ?>-(<?php echo e($category->product_count); ?>)</h1>
            <div class="fashion_section_2">
                <div class="row">

                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-sm-4">
                            <div class="box_main">
                                <h4 class="shirt_text"><?php echo e($product->product_name); ?></h4>
                                <p class="price_text">Price <span style="color: #262626;"><?php echo e($product->price); ?></span>
                                </p>
                                <div class="tshirt_img"><img src="<?php echo e(asset($product->product_img)); ?>"></div>
                                <div class="btn_main">
                                    <div class="buy_bt"><a href="">Buy Now</a></div>
                                    <div class="seemore_bt"><a href="">See More</a></div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user_template.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\singleeco\resources\views/user_template/category.blade.php ENDPATH**/ ?>