<?php $__env->startSection('page_title'); ?>
    All Products - Single Ecom
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <!-- Bootstrap Table with Header - Light -->
    <div class="container-xxl flex-grow-1 container-p-y">
        <h4 class="fw-bold py-3 mb-4"><span class="text-muted fw-light">Pages/</span>All Product</h4>
            <?php if(session()->has('message')): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get('message')); ?>

                </div>
            <?php endif; ?>
        <div class="card">
            <h5 class="card-header">Available Products Information</h5>
            <div class="table-responsive text-nowrap">
                <table class="table">
                    <thead class="table-light">
                        <tr>
                            <th>Id</th>
                            <th>Product Name</th>
                            <th>Image</th>
                            <th>Price</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($product->id); ?></td>
                            <td><?php echo e($product->product_name); ?></td>
                            <td>
                                <img style="height: 100px;" src="<?php echo e(asset($product->product_img)); ?>" alt="">
                                <br>
                                <a href="<?php echo e(route('editproductimg', $product->id)); ?>" class="btn btn-primary">Update Image</a>
                            </td>
                            <td><?php echo e($product->price); ?></td>
                            <td>
                                <a href="<?php echo e(route('editproduct', $product->id )); ?>" class="btn btn-primary">Edit</a>
                                <a href="<?php echo e(route('deleteproduct', $product->id )); ?>" class="btn btn-warning">Delete</a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Bootstrap Table with Header - Light -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\singleeco\resources\views/admin/allproduct.blade.php ENDPATH**/ ?>