<?php $__env->startSection('page_title'); ?>
Dashboard - Single Ecom
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>This is add Dashboard page</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\singleeco\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>