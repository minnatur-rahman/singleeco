<?php $__env->startSection('page_title'); ?>
Pending Order - Single Ecom
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<h1>This is pending order page</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\singleeco\resources\views/admin/pendingorder.blade.php ENDPATH**/ ?>