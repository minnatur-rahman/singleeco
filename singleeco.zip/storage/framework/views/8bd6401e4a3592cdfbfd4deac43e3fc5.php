<?php $__env->startSection('main-content'); ?>
<h1>I am User Profile  page</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('user_template.layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\singleeco\resources\views/user_template/userprofile.blade.php ENDPATH**/ ?>